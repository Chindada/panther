BEGIN;
DROP TABLE IF EXISTS system_event_login;
DROP TABLE IF EXISTS system_account;
DROP TABLE IF EXISTS system_totp;
COMMIT;

