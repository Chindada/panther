#!/bin/bash

flutter pub add \
    fixnum \
    protobuf
